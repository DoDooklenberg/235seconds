#include "lightbulbsmodule.h"

LightBulbsModule::LightBulbsModule(sf::Vector2f newOrigin, float newSide, std::string newSerial, sf::Font newFont) : BaseModule(newOrigin, newSide, newSerial, newFont)
{

}

void LightBulbsModule::process(sf::RenderWindow *window, int time)// Логика обработки событий(Нажатие мыши, и т д)
{

}

void LightBulbsModule::render(sf::RenderWindow *window) // Отрисовка
{
    std::array vertices =
        {
         sf::Vertex{{origin.x, origin.y}},
         sf::Vertex{{origin.x + side, origin.y}},
         sf::Vertex{{origin.x + side, origin.y + side}},
         sf::Vertex{{origin.x, origin.y + side}},
         sf::Vertex{{origin.x, origin.y}},
         };

    window->draw(vertices.data(), vertices.size(), sf::PrimitiveType::LineStrip);
}
