#ifndef LIGHTBULBSMODULE_H
#define LIGHTBULBSMODULE_H

#include "basemodule.h"


class LightBulbsModule : public BaseModule
{
public:
    LightBulbsModule(sf::Vector2f newOrigin, float newSide, std::string newSerial, sf::Font newFont);
    void process(sf::RenderWindow *window, int time);
    void render(sf::RenderWindow *window);
};

#endif // LIGHTBULBSMODULE_H
